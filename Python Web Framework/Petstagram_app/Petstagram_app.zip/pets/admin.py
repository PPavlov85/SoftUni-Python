from django.contrib import admin
from pets.models import Pet, Like

admin.site.register(Pet)
admin.site.register(Like)
