# from problem3.project.knight import Knight
from project.knight import Knight

class DarkKnight(Knight):
    pass
