# from problem3.project.elf import Elf
from project.elf import Elf

class MuseElf(Elf):
    pass