# from problem3.project.hero import Hero
from project.hero import Hero

class Elf(Hero):
    pass