# from Zoo.project.reptile import Reptile
from project.reptile import Reptile

class Snake(Reptile):
    def __init__(self, name):
        super(Snake, self).__init__(name)
