# from Zoo.project.mammal import Mammal
from project.mammal import Mammal

class Bear(Mammal):
    def __init__(self, name):
        super(Bear, self).__init__(name)
